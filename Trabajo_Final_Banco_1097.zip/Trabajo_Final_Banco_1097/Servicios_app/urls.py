from django.urls import  path
from Servicios_app import views

urlpatterns = [
    path('', views.inicio_vista, name='inicio_vista'),
    path('registrarServicios/', views.registrarServicios, name='registrarServicios'),
    path("seleccionarServicios/<Id_Servicio>",views.seleccionarServicios,name="seleccionarServicios"),
    path("editarServicios/",views.editarServicios,name="editarServicios"),
    path("borrarServicios/<Id_Servicio>",views.borrarServicios,name="borrarServicios"),
] 