from django.apps import AppConfig


class ServiciosAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Servicios_app'
