from django.contrib import admin
from.models import Socios

# Register your models here.

admin.site.register(Socios)