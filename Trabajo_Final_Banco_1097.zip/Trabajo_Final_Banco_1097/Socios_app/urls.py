from django.urls import  path
from Socios_app import views

urlpatterns = [
    path('', views.inicio_vista, name='inicio_vista'),
    path('registrarSocios/', views.registrarSocios, name='registrarSocios'),
    path("seleccionarSocios/<Id_Socio>",views.seleccionarSocios,name="seleccionarSocios"),
    path("editarSocios/",views.editarSocios,name="editarSocios"),
    path("borrarSocios/<Id_Socio>",views.borrarSocios,name="borrarSocios"),
] 