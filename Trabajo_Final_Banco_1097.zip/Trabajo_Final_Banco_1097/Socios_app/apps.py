from django.apps import AppConfig


class SociosAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Socios_app'
