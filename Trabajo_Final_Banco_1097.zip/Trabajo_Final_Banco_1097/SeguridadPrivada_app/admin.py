from django.contrib import admin
from.models import Seguridad_Privada

# Register your models here.

admin.site.register(Seguridad_Privada)