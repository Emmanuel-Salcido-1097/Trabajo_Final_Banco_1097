from django.urls import  path
from Empleados_app import views

urlpatterns = [
    path('', views.inicio_vista, name='inicio_vista'),
    path('registrarEmpleados/', views.registrarEmpleados, name='registrarEmpleados'),
    path("seleccionarEmpleados/<Id_Empleado>",views.seleccionarEmpleados,name="seleccionarEmpleados"),
    path("editarEmpleados/",views.editarEmpleados,name="editarEmpleados"),
    path("borrarEmpleados/<Id_Empleado>",views.borrarEmpleados,name="borrarEmpleados"),
] 